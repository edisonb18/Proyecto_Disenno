package strategy;

import Interfaces.ImplementarReporte;

public class Contexto implements ImplementarReporte{
    private Strategy strategy;
    
    @Override
    public void generarReporteInyeccion(String tipo, String consulta, String ruta){
        switch(tipo){
            case "Pdf":
                strategy= new Pdf();
                strategy.crearDocumento(consulta, ruta);
                break;
            case "Imagen":
                strategy= new Imagen();
                strategy.crearDocumento(consulta, ruta);
                break;
            default:
                break;
        }
    }
}
