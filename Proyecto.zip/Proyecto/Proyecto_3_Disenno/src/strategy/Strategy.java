package strategy;

public interface Strategy {
    public void crearDocumento(String string, String ruta);
}
