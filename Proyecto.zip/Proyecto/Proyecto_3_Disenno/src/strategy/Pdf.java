package strategy;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class Pdf implements Strategy{
 
    @Override
    public void crearDocumento(String txt, String ruta){
        try{
            FileOutputStream archivo = new FileOutputStream(ruta+".pdf");
            Document doc= new Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();
            doc.add(new Paragraph(txt));
            doc.close();
        }catch(Exception e){
            System.out.println("Error");
        }
        
    }
    

}
