package Proyecto_3_Disenno;

import Estructuras.Controladora;
import Interfaces.ImplementarContrasenaValidar;
import composite.Composite_Validador;
import composite.Validar_Contrasena;
import java.util.ArrayList;
import java.util.List;
import strategy.Contexto;

public class Controlador extends Controladora{

    private static Controlador controlador = null;
    
    public Controlador() {
        Contexto contexto= new Contexto();
        gReporte_y_Consulta.setGenerarReporte(contexto);
        
        //----------------------------------------------------------------------
        List<ImplementarContrasenaValidar> validators = new ArrayList();
        Composite_Validador validar;
        validators.add(new Validar_Contrasena());
        validar = new Composite_Validador(validators);
        
        gUsuario.setValidadores(validar);
    }
    
    public static Controlador getInstance() 
    { 
        if (controlador == null) {
            controlador = new Controlador(); 
        }
  
        return controlador; 
    }
    
    public void generar_reporte(String tipo, String consulta, String ruta){
        gReporte_y_Consulta.generarReporte(tipo, consulta, ruta);
    }
    public List validar_cambio(String contrasenna){
       return gUsuario.revisarFormato(contrasenna);
    }
}
