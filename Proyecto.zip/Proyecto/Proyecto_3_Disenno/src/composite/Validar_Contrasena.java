package composite;

import Interfaces.ImplementarContrasenaValidar;
import java.util.ArrayList;
import java.util.List;

public class Validar_Contrasena implements ImplementarContrasenaValidar<String>{

    @Override
    public List<String> validar(String info) {
       List<String> validations = new ArrayList();
        
        if (info.isEmpty()) {
            validations.add("La contraseña no puede estar vacía.");
        }
        if (info.contains("\\")) {
            validations.add("La contraseña no puede contener el símbolo '\\'");
        }
        if (info.contains(" ")) {
            validations.add("La contraseña no puede contener espacios.");
        }
        if (info.length() <= 5) {
            validations.add("La contraseña debe tener una tamaño mayor o igual"
                    + " a 6.");
        }
        if (!info.matches(".*\\p{javaLowerCase}+.*")) {
            validations.add("La contraseña debe tener al menos una minúscula.");
        }
        if (!info.matches(".*\\p{javaUpperCase}+.*")) {
            validations.add("La contraseña debe tener al menos una mayúscula.");
        }
        if (!info.matches(".*[0-9].*")) {
            validations.add("La contraseña debe tener al menos un número.");
        }
        return validations; 
    }
    
}
