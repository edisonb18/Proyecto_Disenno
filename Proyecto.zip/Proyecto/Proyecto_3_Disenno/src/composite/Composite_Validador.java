package composite;

import Interfaces.ImplementarContrasenaValidar;
import java.util.ArrayList;
import java.util.List;

public class Composite_Validador<T> implements ImplementarContrasenaValidar<T> {
    
    private List<ImplementarContrasenaValidar<T>> validadores;
    
    public Composite_Validador() {
        validadores = new ArrayList();
    }
    
    public Composite_Validador(List<ImplementarContrasenaValidar<T>> validadores) {
        this.validadores = validadores;
    }
    
    public ImplementarContrasenaValidar add(ImplementarContrasenaValidar validador) {
        validadores.add(validador);
        return validador;
    }

    @Override
    public List validar(T info) {
        List<String> validations = new ArrayList();
        validadores.forEach(validador -> 
                           validations.addAll(validador.validar(info)));        
        return validations;
    }
}
